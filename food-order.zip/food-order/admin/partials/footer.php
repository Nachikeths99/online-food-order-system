<!--footer starts-->
<div class="footer">
            <div class="wrapper">
                <div class="text-center">
                    <p><i class="fa-regular fa-copyright"></i>  2022 All Rights Reserved.</p>
                    <p><i class="fa-solid fa-code"></i>  Developed and Designed by Tarun R Karkera.</p>
                </div>            
            </div>
        </div>
        <!--footer ends-->
    </body>
</html>