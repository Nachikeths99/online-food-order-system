
    <!-- social Section Starts Here -->
    <section class="social">
        <div class="mycontainer text-center">
            <ul>
                <li>
                    <a href=""><i class="fa-brands fa-facebook fa-3x"></i></i></a>
                </li>
                <li>
                    <a href=""><i class="fa-brands fa-instagram  fa-3x"></i></a>
                </li>
                <li>
                <a href=""><i class="fa-brands fa-twitter fa-3x"></i></a>
                </li>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->

    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="foot">
            <div class="mycontainer text-center">
                <p><i class="fa-regular fa-copyright"></i>  All Rights Reserved.</p>
                <p><i class="fa-solid fa-code"></i>Developed and Designed by Tarun R Karkera.</p>
            </div>
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>